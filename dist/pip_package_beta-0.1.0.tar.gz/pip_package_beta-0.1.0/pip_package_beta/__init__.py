def greet(name: str) -> str:
    return f"Hello {name}, this is my first (Beta) pip package!"